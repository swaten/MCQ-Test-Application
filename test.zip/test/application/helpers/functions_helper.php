<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

/*------ check logged user -------*/
	function chk_logged_admin()
	{
		$ci = get_instance();
		$logged_user = $ci->session->email_id;
		
		if(isset($logged_user) && !empty($logged_user)) 
		{
			return true;
		}
		else return false;
        
	}
	
	function chk_logged_user()
	{
		$ci = get_instance();
		$logged_user = $ci->session->qur_login_id;
		
		if(isset($logged_user) && !empty($logged_user)) 
		{
			return true;
		}
		else return false;
        
	}
/*------ check logged user -------*/



/*------ Function Check Access -------*/

	function chk_access($module)
	{
		$ci = get_instance();
		$ci->db->where('level',$_SESSION['anly_type']);
		$ci->db->where('module_name',$module);
		$result = $ci->db->get('module_access_matrix');
		if ($result->num_rows() > 0)
		{
			return true;
		}
		else{
			return false;
		}
	}

/*------ Function Check Access -------*/

/*------ Function Send Mail --------*/

	function custom_send_email($param)
	{
		if(!SEND_EMAIL) return true;;
		$ci = get_instance();
		$from = $param['from'];
		$from_name = $param['from_name'];
		$subject = $param['subject'];
		$to = $param['to'];
		//$msg = $param['email_message'];
		$msg = $param['email_message'];
		$smtp = true;
		//$smtp = false;
		$email_config = array();
		$email_config['protocol'] = 'smtp';
		$email_config['smtp_host']    = 'ssl://email-smtp.us-east-1.amazonaws.com';
		$email_config['smtp_port']    = 465; //SSL port
		$email_config['smtp_timeout'] = '7';
		$email_config['smtp_user']    = 'AKIASFYRCM5Z3MV2TUWD';
		$email_config['smtp_pass']    = 'BHpkNpahL/P1DGTlnP2BnGeJB5wT7WJxXuY7ukDWU4To';
		$email_config['charset']    = 'utf-8';
		$email_config['mailtype'] = 'html';
		$email_config['newline'] = "\r\n";
		/*$config2 = array();
		$config2['protocol'] = 'smtp';
		$config2['smtp_host'] = 'ssl://smtp.gmail.com';
		$config2['smtp_port'] = 465; //SSL port
		$config2['smtp_user'] = 'noreplynfa@mobilestyx.co.in'; //jlrmenasupport@mobilestyx.co.in
		$config2['smtp_pass'] = '0Ijzk2Vb*w0R'; //
		$config2['charset'] = 'utf-8';
		$config2['mailtype'] = 'html';
		$config2['newline'] = "\r\n";*/		
		
		if($smtp)
		{
			$ci->load->library('email');
			$ci->email->initialize($email_config);
		}
		else
		{
			$ci->load->library('email');
			$ci->email->initialize($email_config);
		}
		$ci->email->reply_to($from, $from_name);
		$ci->email->from($from, $from_name);
		$ci->email->to(array("sayali.s@mobilestyx.co.in","dharmesh.p@mobilestyx.co.in"));
		if(isset($param['cc']) && $param['cc'] != '') $ci->email->cc($param['cc']);
		if(isset($param['bcc']) && $param['bcc'] != '') $ci->email->bcc($param['bcc']);
		$ci->email->subject($subject);
		if (isset($param['file']) && $param['file'] != ''){ 
			$ci->email->attach($param['file'], 'attachment', $param['filename'], 'application/pdf');
			//echo 'file';
		}
		
		$ci->email->message($msg);
		$send_mail = $ci->email->send();
		/*$x = $ci->email->print_debugger();
		print_r($x);*/
		$ci->email->clear(TRUE);
		return $send_mail;
	}
	
/*------ Function Send Mail --------*/
	
/*------ Function Custom Print --------*/
	
	function print_r_custom ($expresion, $hidden=false) 
	{
		if ($hidden) echo '<pre style="display:none;">';
			else echo '<pre>';
		print_r($expresion);
		echo '</pre>';
	}

/*------ Function Custom Print --------*/

/*------ Function Custom Var Dump --------*/

	function var_dump_custom ($expresion, $hidden=false) 
	{
		if ($hidden) echo '<pre style="display:none;">';
			else echo '<pre>';
		var_dump($expresion);
		echo '</pre>';
	}
	
/*------ Function Custom Var Dump --------*/

/*------ Function Generate Customr File Name --------*/

	function custom_file_name($str,$end){
		$str1 = str_replace(' ','_',$str);
		$result = time().'_'.substr($str1, 0, $end);
		return $result;
	}

/*------ Function Generate Customr File Name --------*/

/*------- Function Number Formate Custom ----------*/

	function number_format_custom ($number) {
		$number = strval($number);
		$number = explode('.',$number);
		$decimal_val = (isset($number[1])) ? $number[1] : '' ;
		$number = intval($number[0]);
		$strlen = strlen($number);
		$before_dec = &$number;
		if ($strlen > 3) {
			if(($strlen % 2) == 0) $first_split = 1;
			else $first_split = 2;
			$num_of_loops = ($strlen - ($first_split + 3))/2;
			$str_pos = 0;
			$formated_number = substr($before_dec, $str_pos, $first_split) . ',';
			$str_pos += $first_split;
			for ($i=0; $i<$num_of_loops; $i++) {
				$formated_number .= substr($before_dec, $str_pos, 2) . ',';
				$str_pos += 2;
			}
			$formated_number .= substr($before_dec, -3, 3);
			if ($decimal_val=='') return 'INR '. $formated_number;
			else return "INR " . $formated_number . "." . $decimal_val;
		} else {
			if ($decimal_val=='') return 'INR '.$before_dec;
			else return "INR " . $before_dec . "." . $decimal_val;
		}
	}
	
/*------- Function Number Formate Custom ----------*/

/*------- Function To Check Access ----------*/

	function check_access (&$controller, $access_type) {
		$query = $controller->db->query("SELECT * FROM vme_page_access t1 JOIN vme_page_access_map t2 ON t1.access_id=t2.access_id WHERE t1.type='$access_type' AND t2.level='{$_SESSION['vme_user_type']}' ");
		if ($query->num_rows()) return true;
		else return false;
	}
	
/*------- Function To Check Access ----------*/
	
/*------- Function To Download CSV File -----------*/

	function output_csv (&$data, $file_name) {
		header("Content-type: text/csv");
		header("Content-Disposition: attachment; filename=$file_name");
		header("Pragma: no-cache");
		header("Expires: 0");
		
		if (!count($data)) echo '"No Data"';
		else {
			// echoing header of csv
			$row_data = array();
			foreach ($data[0] as $key=>$element) $row_data[] = '"'.str_replace('"','\"',$key).'"';
			echo implode(',', $row_data). "\n";
			
			foreach ($data as &$row) {
				$row_data = array();
				foreach ($row as &$element) $row_data[] = '"'.str_replace('"','\"',$element).'"';
				echo implode(',', $row_data). "\n";
			}
		}
	}
	
/*------- Function To Download CSV File -----------*/

/*---------- Get Financial Year On Basis of quarter -----------*/

	function get_financial_year($year,$quarter){
		if(is_numeric($year) && is_numeric($quarter)){
			if(intval($quarter) == 2){
				return ($year-1).'-'.$year;
			}
			else{
				return $year.'-'.($year+1);
			}
		}
		else{
			return false;
		}
	}
	
	function custom_encrypt($data,$data_key){
	    
	    return openssl_encrypt($data, 'AES128', $data_key);
	}
	
	function custom_decrypt($data,$data_key){
	    
	    return openssl_decrypt($data, 'AES128', $data_key);
	}
	
	function post_validation ($check_params, &$response_addr) {
		/*$empty_values = array(
			'first_name'=>array(''),
			'last_name'=>array(''),
			'mobile_no'=>array('int'),
			'email'=>array('email'),
			'city'=>array(''),
			'brand'=>array(''),
			'model'=>array(''),
			'existing_brand'=>array(''),
			'existing_model'=>array(''),
			'hear_about_jlr'=>array(''),
			'source'=>array(''),
			'industry'=>array('')
		);*/
		foreach ($check_params as $key => &$values) foreach ($values as $possible_value) {
			$possible_value = explode('|', $possible_value);
			switch ($possible_value[0]) {
				case "isset" :
					if (!isset($_POST[$key])) {
						$key = str_replace('_', ' ', $key);
						$response_addr = "Please set $key.";
						return false;
					}
				break;
				case "file_empty" :
					if (empty($_FILES[$key]) || empty($_FILES[$key]) || $_FILES[$key]['name']=='') {
					    $key = str_replace('declare_letter', 'Declaration_Letter', $key);
						$key = str_replace('_', ' ', $key);
						$response_addr = "Please attach $key.";
						return false;
					}
				break;
				case "not_blank":
				    if(trim($_POST[$key]) == ''){
				        $key = str_replace('_', ' ', $key);
						$response_addr = $key." is required.";
						return false;
				    }
				break;
				case "int" :
					if (!intval($_POST[$key])) {
						$key = str_replace('_', ' ', $key);
						$response_addr = "Invalid input for $key.";
						return false;
					}
				break;
				case "email" :
					if (!filter_var($_POST[$key], FILTER_VALIDATE_EMAIL)) {
						$key = str_replace('_', ' ', $key);
						$response_addr = "Invalid input for $key.";
						return false;
					}
				break;
				case "length" :
					if (strlen($_POST[$key])!= $possible_value[1]) {
					    $key = str_replace('mobile_no', 'mobile_number', $key);
						$key = str_replace('_', ' ', $key);
						//$response_addr = "There should be {$possible_value[1]} char in $key.";
						$response_addr = "Please enter {$possible_value[1]} digit $key.";
						return false;
					}
				break;
				case "min_length" :
					if (strlen($_POST[$key])< $possible_value[1]) {
						$key = str_replace('_', ' ', $key);
						$response_addr = "There should be atleast {$possible_value[1]} char in $key.";
						return false;
					}
				break;
				case "min" :
					if (intval($_POST[$key]) < $possible_value[1]) {
						$key = str_replace('_', ' ', $key);
						$response_addr = ucfirst("$key should be atleast {$possible_value[1]}.");
						return false;
					}
				break;
				case "max" :
					if (intval($_POST[$key]) > $possible_value[1]) {
						$key = str_replace('_', ' ', $key);
						$response_addr = ucfirst("$key cannot be greater than {$possible_value[1]}.");
						return false;
					}
				break;
				default :
					if (intval($possible_value[0]) && strlen($_POST[$key])!= $possible_value[0]) {
						$key = str_replace('_', ' ', $key);
						$response_addr = "There should be {$possible_value[0]} char in $key.";
						return false;
					} 
					elseif ($key == 'mobile_no' && strlen($_POST[$key]) == $possible_value[0]) {
					    $key = str_replace('mobile_no', 'mobile_number', $key);
						$key = str_replace('_', ' ', $key);
						$response_addr = "Please enter $key.";
						return false;
					}elseif (in_array($key,array('rad')) && strlen($_POST[$key]) == $possible_value[0]) {
						$key = str_replace('_', ' ', $key);
						$response_addr = "Please select $key.";
						return false;
					}
			}
		}
		
		return true;
	}
	
	function custom_sms_sent_old($mobile_number,$sms_content){
	    	
	    $sms_api_key = 'A3dcbe4fb973dbb06360d363aaf5e02cf';
        $sms_send_id = 'MOSTYX';
        $sms_api_url = 'http://trans.kapsystem.com/api/v3/';
        $tc_link = 'https://bit.ly/2p0vmcL';
        
        $sms_string = $sms_api_url.'?method=sms&api_key='.$sms_api_key.'&to='.$mobile_number.',&sender='.$sms_send_id.'&format=XML&message='.urlencode($sms_content);
        return file_get_contents($sms_string);
	}
	
   function custom_sms_sent($mobile_number,$sms_content)
    {
    	$sms_gatway = array(
    	    'api_user' => 'evanmobstyx',
    	    'api_password' => 'NzHsmvOj',
    	    'api_url' => 'http://193.105.74.159/api/v3/sendsms/plain', //'http://193.105.74.159/api/v3/sendsms/plain',
    	    'api_sender_id' => 'KAPINT'  //'JLRBAH'
    	 );
    	
        $sms_string = $sms_gatway['api_url'].'?user='.$sms_gatway['api_user'].'&password='.$sms_gatway['api_password'].'&sender='.$sms_gatway['api_sender_id'].'&SMSText=' . urlencode(str_replace('&nbsp;',' ',strip_tags($sms_content))). '&type=longsms&GSM='.$mobile_number;
        
    	return file_get_contents($sms_string);
        
    }
	
	function verify_auth ($param) {
	    //return print_r_custom($param);
     	if(isset($_POST['user']) && isset($_POST['pass']) && strip_tags($_POST['user']) == $param['user'] && strip_tags($_POST['pass']) == $param['pass'])
     		return true;
     	else return false;
     	// return print_r_custom($_POST);
    }

/*---------- Get Financial Year On Basis of quarter -----------*/
/*---------- Get Abbreviations Of Police Level -----------*/

    function abb_level($level)
    {
       
            switch ($level) {
        case "traffic_clerk":
            return "TC";
            break;
        case "chief":
            return "C";
            break;
        case "police_officer":
            return "PC";
            break;
             case "supervisor":
            return "S";
            break;
            case "police_constable":
            return "PC";
            break;
            
        default:
             return "";
        }
    
    }
/*---------- Get Abbreviations Of Police Level -----------*/

   function ticket_format($ticket_no){
    return str_pad($ticket_no, 7, '0', STR_PAD_LEFT);
    
}


    function custom_save_pdf($html,$pdf_name,$output = 'save',$document = array(),$path = 'pon_pdfs/web/')
    {
        $default_document = array(
            'paper_size' => (!empty($document) && $document != null && isset($document['paper_size']) ? $document['paper_size'] : array(0,0,612,792)),
            'paper_type' => (!empty($document) && $document != null && isset($document['paper_type']) ? $document['paper_type'] : 'Landscape')
        );
        
        require_once APPPATH.'third_party/dompdf/lib/html5lib/Parser.php';
        require_once APPPATH.'third_party/dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
        require_once APPPATH.'third_party/dompdf/lib/php-svg-lib/src/autoload.php';
        require_once APPPATH.'third_party/dompdf/src/Autoloader.php';
        Dompdf\Autoloader::register();
        //use Dompdf\Dompdf;
        
        $ci = get_instance();
        $ci->dompdf = new Dompdf\Dompdf;
        $ci->dompdf->load_html(json_decode($html));
        $ci->dompdf->set_option('isHtml5ParserEnabled', true);
        $ci->dompdf->setPaper($default_document['paper_size'], $default_document['paper_type']);
        $ci->dompdf->render();
        if($output != 'save')
        {
            $ci->dompdf->stream($pdf_name. '.pdf');
        }
        else
        {
            $output = $ci->dompdf->output();
            file_put_contents($path.$pdf_name.'.pdf', $output);
            return true;
        }
    }
	
	/*---------- Admin Access Police Level  -----------*/
	
	function can_access($role,$action){
		$ci = get_instance();
		$role = strtolower($role).'_access';
		$ci->db->where($role,'Y');
		$ci->db->where('action_name',$action);
		$query = $ci->db->get('users_access_level');
		// echo $ci->db->last_query();
		if ($query->num_rows() > 0)
		{
			return true;
		}
		else return false;
		// return $ci->authenticate_model->can_access($role,$action);
	}
	/*---------- Admin Access Police Level -----------*/

	function custom_show_error($message = '')
	{
		 //echo $message;die();
		$ci = get_instance();
		$ci->load->view("admin/errors/error_general",array('message'=>$message));
	}
	
	function missing_number($num_list) { 
      // construct a new array 
      $new_arr = range($num_list[0],max($num_list)); 
      // use array_diff to find the missing elements 
      return array_diff($new_arr, $num_list);
    } 
    
    function maintain_users_log($data){
        $ci = get_instance();
        $ci->load->library('user_agent');
        $ci->load->model(array('admin/user_actions_logs_model'));
        $data['ip'] = $ci->input->ip_address();
        $data['user_agent'] = $ci->agent->agent;
        $data['time'] = time();

        $inserted_id = $ci->user_actions_logs_model->insert($data);
        if($inserted_id) return true;
        else return false;
   
    }
	
?>