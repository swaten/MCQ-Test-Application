<?php
class Mcq_question_list_mdl extends MY_Model
{
      public $table = 'mcq_question_list';
    	
}
?>