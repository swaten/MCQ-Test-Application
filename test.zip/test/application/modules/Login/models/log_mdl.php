<?php
class Log_mdl extends MY_Model
{
      public $table = 'users';
    	
}
?>