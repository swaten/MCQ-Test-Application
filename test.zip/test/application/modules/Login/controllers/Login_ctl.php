<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Login_ctl extends MY_Controller {

	
	public function index()
	{

		$data['admin_id'] = 'admin@gmail.com';
		$this->load->view('login/sign_in_view',$data);
	}

	public function get_api_data(){
		
		$api = file_get_contents(API_URL);
		$json_data = json_decode($api, true);
		$questions_list = $json_data['results'];
		
		$data = array();
		foreach($questions_list as $row){
			$data[] = array(
								'incorrect_answers'=>implode(",", $row['incorrect_answers']),
								'category' => $row['category'],
								'type' => $row['type'],
								'difficulty' => $row['difficulty'],
								'question' => $row['question'],
								'correct_answer' => $row['correct_answer'],
							);
		}

		
		$this->load->model('mcq_question_list_mdl');
		
		if($insert_id>0){
			echo json_encode(array('msg'=>'Question List Updated'));
		}
		else{
			echo json_encode(array('msg'=>'Error Not list Updated'));
		}
	}

	public function sign_in(){
		$this->load->model('log_mdl');
		//print_r_custom($_POST);
		if($_POST['login_type'] == 'admin'){
			
				$password=$_POST['pass'];
				
				$user_data = $this->log_mdl->get_where_single(array('email_id'=>$_POST['email'],'pass'=>$password));

					if(is_array($user_data)){
								$_SESSION['login_type'] = $user_data['type'];
								$_SESSION['name'] = $user_data['name'];
								$_SESSION['email_id'] = $user_data['email_id'];				
								
								echo json_encode(array('status'=>200,'msg'=>'Logging in as admin'));
					}
					else echo json_encode(array('status'=>400,'msg'=>'Data Did not Match'));
				}
			
		
		else if($_POST['login_type'] == 'guest') {
			$email = $_POST['email'];
			$user_data = count($this->log_mdl->get_where_single(array('email_id'=>$_POST['email']))['email_id']);
			
			if($user_data > 0){
				echo json_encode(array('status'=>400,'msg'=>'Guest Already Existed'));
			}
			else{
				$rand = rand(1,50000);
				$name = 'guest_'.$rand;
				$time = date('Y-m-d');
				$data = array('type'=>'guest','email_id'=>$email,'created_date'=>$time,'name'=>$name);
				$this->log_mdl->insert($data);

				$_SESSION['login_type'] = $data['type'];
				$_SESSION['name'] = $data['name'];
				$_SESSION['email_id'] = $data['email_id'];
				echo json_encode(array('status'=>200,'msg'=>'Logging in as Guest'));
			}
			//print_r_custom($user_data);
			# code...
		}
		else{
			echo json_encode(array('msg'=>'400 error'));
		}
			
    }
		}

?>