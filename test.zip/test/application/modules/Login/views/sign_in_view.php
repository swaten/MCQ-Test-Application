<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from coderthemes.com/minton/layouts/vertical/blue/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 May 2020 06:59:44 GMT -->
<head>
        <title>Lyricist - Sign In</title>
<?php require('head.php');?>
    </head>

    <body>

        <div class="account-pages mt-5 mb-5" id="sign_in_admin" style="display: none;">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                        <div class="card">

                            <div class="card-body p-4">
                                
                                <div class="text-center w-75 m-auto">
                                    <a href="#">
                                        <!-- <h1>Lyricist</h1> -->
                                    </a>
                                   <!--  <p class="text-muted mb-4 mt-3">Enter your email address and password to sign in.</p> -->
                                </div>

                                <form action="#" id="admin_form">

                                    <div class="form-group mb-3">
                                        <label for="emailaddress">Email address</label>
                                        <input class="form-control" type="email" id="sign_in_email" name="email" required="" placeholder="Enter your email" value="<?php echo $admin_id;?>" disabled style="background-color: #e4dede">
                                        <input type="hidden"  name="email" value="<?php echo $admin_id;?>"  >
                                        <input type="hidden" name="login_type" value="admin">
                                    </div>

                                    <div class="form-group mb-3">
                                        <label for="password">Password</label>
                                        <input class="form-control" type="password" id="sign_in_pass" name="pass" required="" id="password" placeholder="Enter your password">
                                    </div>

                                    <!-- <div class="form-group mb-3">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="checkbox-signin" checked>
                                            <label class="custom-control-label" for="checkbox-signin">Remember me</label>
                                        </div>
                                    </div> -->

                                    <div class="form-group mb-0 text-center">
                                        <button class="btn btn-primary btn-block" id="sign_admin" type="button"> Sign In </button>
                                    </div>

                                </form>

                               

                            </div> <!-- end card-body -->
                        </div>
                        <!-- end card -->

                        
                        <!-- end row -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>

        <div class="account-pages mt-5 mb-5" id="sign_in_guest" style="display: none;">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                        <div class="card">

                            <div class="card-body p-4">
                                
                                <div class="text-center w-75 m-auto">
                                    <a href="#">
                                        <!-- <h1>Lyricist</h1> -->
                                    </a>
                                   <!--  <p class="text-muted mb-4 mt-3">Enter your email address and password to sign in.</p> -->
                                </div>

                                <form action="#" id="guest_form">

                                    <div class="form-group mb-3">
                                        <label for="emailaddress">Email address</label>
                                        <input class="form-control" type="email" id="sign_in_email" name="email" required="" placeholder="Enter your email"  style="background-color: #e4dede">
                                        <input type="hidden" name="login_type" value="guest">
                                    </div>

                                   <!--  <div class="form-group mb-3">
                                        <label for="password">Password</label>
                                        <input class="form-control" type="password" id="sign_in_pass" name="pass" required="" id="password" placeholder="Enter your password">
                                    </div> -->

                                    <!-- <div class="form-group mb-3">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="checkbox-signin" checked>
                                            <label class="custom-control-label" for="checkbox-signin">Remember me</label>
                                        </div>
                                    </div> -->

                                    <div class="form-group mb-0 text-center">
                                        <button class="btn btn-primary btn-block" id="sign_guest" type="button"> Sign In </button>
                                    </div>

                                </form>

                               

                            </div> <!-- end card-body -->
                        </div>
                        <!-- end card -->

                        
                        <!-- end row -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>

         <div class="account-pages mt-5 mb-5" id="log_card">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-12 col-lg-6 col-xl-5">
                        <div class="row">
                          <div class="col-sm-6">
                            <div class="card">
                              <div class="card-body">
                                <h5 class="card-title">Guest</h5>
                                <p class="card-text">Start as Guest</p>
                                <a href="#" id="guest_login" class="btn btn-primary">Login</a>
                              </div>
                            </div>
                          </div>
                          <div class="col-sm-6">
                            <div class="card">
                              <div class="card-body">
                                <h5 class="card-title">Admin</h5>
                                <p class="card-text">Start as Admin</p>
                                <a href="#" id="admin_login" class="btn btn-primary">Login</a>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>               
        <!-- end page -->

        <!-- Vendor js -->
        <?php require('footer.php');?>
       
       <script>
        $(function(){
            $('#sign_in_div').hide();
            $("#sign_admin").click(function(){
                $.ajax({
                  url:'<?php echo base_url();?>login/login_ctl/sign_in',
                  type:'POST',
                  dataType:'json',
                  data: $('#admin_form').serialize(),
                  
                  success:function(response)
                  {
                    alert(response.msg);
                    if(response.status==200)
                    {
                      
                       window.location.href="<?php echo base_url();?>home";
                      
                    }
                  }
                });
                
                });

            $("#sign_guest").click(function(){
                $.ajax({
                  url:'<?php echo base_url();?>login/login_ctl/sign_in',
                  type:'POST',
                  dataType:'json',
                  data: $('#guest_form').serialize(),
                  
                  success:function(response)
                  {
                    alert(response.msg);
                    if(response.status==200)
                    {
                      
                       window.location.href="<?php echo base_url();?>home";
                      
                    }
                  }
                });
                
            });
           

            $("#admin_login").click(function(){
                    $('#sign_in_admin').show();
                    $('#log_card').hide();
                    $('#sign_in_guest').hide();
            });

            $("#guest_login").click(function(){
                    $('#sign_in_guest').show();
                    $('#log_card').hide();
                    $('#sign_in_admin').hide();
                    <?php //$_SESSION['login_type'] = 'guest'; $_SESSION['name'] = 'Guest';?>
                    //window.location.href = '<?php echo base_url();?>home'
            });
        });
       </script> 

    </body>

<!-- Mirrored from coderthemes.com/minton/layouts/vertical/blue/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 May 2020 06:59:45 GMT -->
</html>