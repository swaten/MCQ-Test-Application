<?php
class Users_mcq_score_log_mdl extends MY_Model
{
      public $table = 'users_mcq_score_log';
    
    	public function get_score($question_id='',$ans=''){
    		$this->db->where(array('id'=>$question_id,'correct_answer'=>$ans));
    		$sql = $this->db->get('mcq_question_list');

    		if($sql->num_rows()>0){
    			return 1;
    		}
    		else return 0;
    	}	

    	public function fetch_total_score_data(){
    		$this->db->join('mcq_question_list mql','mql.id='.$this->table.'.question_number');
    		$this->db->where($this->table.'.email_id',$_SESSION['email_id']);
    		$sql = $this->db->get($this->table);
    		//echo $this->db->last_query();
    		if($sql->num_rows()>0){
    			return $sql->result_array();
    		}
    		else return array();

    	}

    	public function get_users(){

    		$this->db->where('usr.email_id !=',$_SESSION['email_id']);
    		$this->db->join('scores_table sct','sct.email_id=usr.email_id');
    		$sql = $this->db->get('users usr');
    		//echo $this->db->last_query();
    		if($sql->num_rows()>0){
    			return $sql->result_array();
    		}
    		else return array();

    	}

    	function insert_score_data($data=''){
    		$this->db->insert('scores_table',$data);
    		return $this->db->insert_id();
    	}
}
?>