<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Home extends MY_Controller {

	function __construct()
	{
        parent::__construct(); 
		if(chk_logged_admin() === false) 
		{
            redirect('');
        }
		
    }
	
	public function index()
	{
		//print_r_custom($_SESSION);
		if($_SESSION['login_type'] == 'guest'){
			$this->load->model('login/mcq_question_list_mdl');
			$data['mcq_questions'] = $this->mcq_question_list_mdl->get_where();
			$this->load->view('home/guest_view',$data);

		}
		else if($_SESSION['login_type'] != 'guest'){
			
			
			$this->load->view('home/admin_view');
		}
		else{
			unset($_SESSION['login_type']);
		}
		// $this->load->view('login/sign_in_view');
	}

	function get_admin_users(){
		 $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));

         $data = array(); 
		$this->load->model('users_mcq_score_log_mdl');
		$users = $this->users_mcq_score_log_mdl->get_users();
		$i=1;
		foreach ($users as $key => $value) {

			 $data[] = array(
			 		$i,
                    $value['name'],
                    $value['email_id'],
                    $value['total_score'],                 
               );
			 $i++;
		}
		$output = array(
               "draw" => $draw,
                 "recordsTotal" => count($users),
                 "recordsFiltered" => count($users),
                 "data" => $data
            );
          echo json_encode($output);
	}

	function submit_ans(){
		$this->load->model('users_mcq_score_log_mdl');
		$time = date('Y-m-d');

		$score = $this->users_mcq_score_log_mdl->get_score($_POST['question_id'],$_POST['optradio']);
		
		$data = array('email_id'=>$_SESSION['email_id'],'question_number'=>$_POST['question_id'], 'score' => $score,'created_date'=>$time,'opt_selected'=>$_POST['optradio']);
		//print_r_custom($data);
		$this->users_mcq_score_log_mdl->insert($data);
		
	}

	function get_your_score(){
		$this->load->model('users_mcq_score_log_mdl');
		$email_id = (!empty($_GET['email_id']) ? $_GET['email_id'] : 0);
		//
		$data['data'] = $this->users_mcq_score_log_mdl->fetch_total_score_data();
		//print_r_custom($data);
		$score_arr = array();
    	foreach($data['data'] as $row){ 
    			$score_arr[] = $row['score'];    		
    		}
    		$total_score = array_sum($score_arr); 
    		$time= date('Y-m-d');
    		$score_data = array('email_id'=>$email_id,'total_score'=>$total_score,'created_date'=>$time);
		$this->users_mcq_score_log_mdl->insert_score_data($score_data);
		$this->load->view('score_view',$data);
	}

	}

?>