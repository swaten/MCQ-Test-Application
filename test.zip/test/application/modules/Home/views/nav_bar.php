<style>
  .pro-user-name{
    font-size: 0.92rem !important;
  }
</style>
<div class="navbar-custom">
                <?php if(isset($_SESSION['stage_name']) && isset($_SESSION['login_id'])) {?>
                <ul class="list-unstyled topnav-menu float-right mb-0">

              
                    <li class="dropdown notification-list">
                        <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                            <img src="<?php echo base_url().ASSETS;?>/images/users/avatar-1.jpg" alt="user-image" class="rounded-circle">
                            <span class="pro-user-name ml-1">
                              Welcome <?php echo $_SESSION['stage_name']?>
                            </span>
                        </a>                       
                    </li>

                    <li class="dropdown notification-list">
                        <a href="javascript:void(0);" class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light">
                                <i class="remixicon-account-circle-line"></i><span class="pro-user-name ml-1">My Account</span>
                            </a>           
                    </li>

                    <li class="dropdown notification-list">
                        <a href="<?php echo base_url().'main_page/sign_out'?>" class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light">
                                <i class="remixicon-logout-box-line"></i><span class="pro-user-name ml-1">Logout</span>
                            </a>                      
                    </li>

                </ul>
              <?php } ?>
                <!-- LOGO -->
                <div class="logo-box">
                    <a href="index.html" class="logo text-center">
                        <span class="logo-lg">
                            <img src="<?php echo base_url().ASSETS;?>/images/logo-light.png" alt="" height="20">
                            <!-- <span class="logo-lg-text-light">Xeria</span> -->
                        </span>
                        <span class="logo-sm">
                            <!-- <span class="logo-sm-text-dark">X</span> -->
                            <img src="<?php echo base_url().ASSETS;?>/images/logo-sm.png" alt="" height="24">
                        </span>
                    </a>
                </div>

                <!-- <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
                    <li>
                        <button class="button-menu-mobile waves-effect waves-light">
                            <i class="fe-menu"></i>
                        </button>
                    </li>

                </ul> -->
            </div>