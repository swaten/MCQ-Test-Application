<div class="left-side-menu">
                <div class="slimscroll-menu">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">

                        <ul class="metismenu" id="side-menu">

                            <li class="menu-title">Features</li>

                            <li>
                                <a href="javascript: void(0);" class="waves-effect">
                                    <i class="remixicon-folder-3-fill"></i>                     
                                    <span> Albums </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                     <li>
                                        <a href="#" data-toggle="modal" data-target="#con-close-modal" data-animation="slit"> <i class="fas fa-plus-circle mr-1"></i>New Album</a>
                                    </li>
                                    <?php if(!empty($_SESSION['album_names'])){

                                        foreach ($_SESSION['album_names'] as $key => $albm_list) {
                                            # code...
                                        
                                        ?>

                                        <li>
                                            <a href="<?php echo base_url().'albums/show_album_data/'.$albm_list['id'];?>"> <i class="remixicon-folder-music-fill mr-1"></i><?php echo $albm_list['album_name'];?></a>
                                        </li>
                                    <?php } }  ?>
                                    
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>


<div id="con-close-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Create Album</h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                </div>
                                                <div class="modal-body p-4">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="field-1" class="control-label">Album Name</label>
                                                                <input type="text" id="album_name" name="album_name" class="form-control" id="field-1" placeholder="whats your album name">
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">Close</button>
                                                    <button type="button" name="add_album" id="add_album" class="btn btn-info waves-effect waves-light">Create</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


