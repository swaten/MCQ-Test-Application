<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from coderthemes.com/minton/layouts/vertical/blue/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 May 2020 06:59:44 GMT -->
<head>
	<style>
		.card-text{
			font-size: 15px !important;
		}
	</style>
        <title>Home</title>
<?php require('head.php');?>
    </head>

    <body>

    	<?php 
    		//print_r_custom($data);
    	$score_arr = array();
    	foreach($data as $row){ 
    			$score_arr[] = $row['score'];
    			$count[] = count($row['id']);
    			$missed_arr []= ($row['question_missed']);
    		?>

    	<?php } 
    	$total_score = array_sum($score_arr); 
    	$question_missed = array_sum($missed_arr);

    	?>	

    	<div class="account-pages mt-5 mb-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-12">                                                                 
                        <div class="card">
                          <div class="card-body">
                            <center><h3 class="card-title">Score Board </h3></center>
                            <p class="card-text"> User Id : <?php echo $row['email_id'];?></p>
                                                        
                            <p class="card-text mb-5"> Total Score : <?php echo $total_score.' / '.count($count);?></p>

                            <?php $i=1;foreach($data as $val){ ?>
                            <p class="card-text " style="color: #2387de"> Questions (<?php echo $i;?>) : <?php echo $val['question'];?></p>

                            <p class="card-text" style="color: #0a9e23"> Correct Answer : <?php echo $val['correct_answer'];?></p>
                            <p class="card-text" style="color: #e00a0a"> Wrong Answers : <?php echo str_replace('/', '  ,  ', $val['incorrect_answers']);?></p>
                            <p class="card-text mb-5" style="color: <?php echo (($val['opt_selected'] == $val['correct_answer']) ? '#f50af9' : '#e00a0a');?>"> Options You Selected : <?php echo $val['opt_selected'];?></p>
                        <?php $i++; } ?>
                            <form action="#" id="">
                                
                            </form> 
                           
                          </div>
                        </div>                          
                    </div>
                </div>
            </div>
          </div>   

 <?php require('footer.php');?>

 </body>

<!-- Mirrored from coderthemes.com/minton/layouts/vertical/blue/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 May 2020 06:59:45 GMT -->
</html>
