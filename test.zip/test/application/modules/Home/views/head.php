<meta charset="utf-8" />
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="<?php echo base_url().ASSETS;?>/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url().ASSETS;?>/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url().ASSETS;?>/css/app.min.css" rel="stylesheet" type="text/css" />
        <link rel="shortcut icon" href="<?php echo base_url().ASSETS;?>/images/favicon.ico">

        <!-- Footable css -->
        <link href="<?php echo base_url().ASSETS;?>/libs/footable/footable.core.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url().ASSETS;?>/libs/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet" />
        <link href="<?php echo base_url().ASSETS;?>/libs/switchery/switchery.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url().ASSETS;?>/libs/multiselect/multi-select.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url().ASSETS;?>/libs/select2/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url().ASSETS;?>/libs/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url().ASSETS;?>/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
         <link href="<?php echo base_url().ASSETS;?>/libs/quill/quill.core.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url().ASSETS;?>/libs/quill/quill.bubble.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url().ASSETS;?>/libs/quill/quill.snow.css" rel="stylesheet" type="text/css" />
        <!-- App css -->
        

<div class="account-pages mt-5 ">
    <div class="container">
        <div class="justify-content-right">        
            <button id='log_out' onclick="sign_out()" class="btn btn-primary"> Sign Out</button>        
        </div>
    </div>
</div>