<!-- <footer class="footer footer-alt">
            Lyricist by  <a href="#" class="text-muted">teddy_musix</a> 
</footer> -->
<script src="<?php echo base_url().ASSETS;?>/js/vendor.min.js"></script>
<script src="<?php echo base_url().ASSETS;?>/js/app.min.js"></script>
<script src="<?php echo base_url().ASSETS?>/js/jquery.min.js"></script>
<script src="<?php echo base_url().ASSETS?>/js/bootstrap.min.js"></script>

<script src="<?php echo base_url().ASSETS?>/libs/footable/footable.all.min.js"></script>
<script src="<?php echo base_url().ASSETS?>/js/pages/foo-tables.init.js"></script>
<script src="<?php echo base_url().ASSETS?>/js/app.min.js"></script>


        <!-- Plugins Js -->
        <script src="<?php echo base_url().ASSETS?>/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
        <script src="<?php echo base_url().ASSETS?>/libs/switchery/switchery.min.js"></script>
        <script src="<?php echo base_url().ASSETS?>/libs/multiselect/jquery.multi-select.js"></script>
        <script src="<?php echo base_url().ASSETS?>/libs/jquery-quicksearch/jquery.quicksearch.min.js"></script>
         <script src="<?php echo base_url().ASSETS?>/libs/select2/select2.min.js"></script>
        <script src="<?php echo base_url().ASSETS?>/libs/bootstrap-select/bootstrap-select.min.js"></script>
        <script src="<?php echo base_url().ASSETS?>/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script src="<?php echo base_url().ASSETS?>/libs/jquery-mask-plugin/jquery.mask.min.js"></script>

        <!-- init js -->
        <script src="<?php echo base_url().ASSETS?>/js/pages/form-advanced.init.js"></script>
        <script src="<?php echo base_url().ASSETS?>/libs/katex/katex.min.js"></script>
        <script src="<?php echo base_url().ASSETS?>/libs/quill/quill.min.js"></script>
        <script src="<?php echo base_url().ASSETS?>/js/pages/form-quilljs.init.js"></script>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.13/datatables.min.css"/>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.13/datatables.min.js"></script> 

<script>
    function sign_out(){
        <?php unset($_SESSION); ?>
                window.location.href="<?php echo base_url();?>";
                
            }
</script>
