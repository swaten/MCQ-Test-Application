<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from coderthemes.com/minton/layouts/vertical/blue/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 May 2020 06:59:44 GMT -->
<head>
        <title>Home</title>
<?php require('head.php');?>
    </head>

    <body>

        <?php //print_r_custom($_SESSION);?>
        <!-- end page -->
        <?php $i=1;
            foreach($mcq_questions as $row){
            $incorrect_answers_arr = explode('/', $row['incorrect_answers']);
            array_push($incorrect_answers_arr, $row['correct_answer']);
                //$options = array_merge($row['correct_answer'],$row['incorrect_answers']);
                //print_r_custom($incorrect_answers_arr);
            ?>
         <div class="account-pages mt-5 mb-5" id="<?php echo $i;?>" style="display:<?php echo ($row['id'] !=1 ? 'none':'block');?>">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-12">                                                                 
                        <div class="card">
                          <div class="card-body">
                            <h4 class="card-title">MCQ TEST</h4>
                            <p class="card-text">Category : <?php echo $row['category'];?></p>
                            <p class="card-text"> Question (<?php echo $i;?>) : <?php echo $row['question'];?></p>
                            <form action="#" id="submit_ans_form_<?php echo $i;?>">
                                <?php for($j=0;$j<count($incorrect_answers_arr);$j++){?>
                                    <div class="form-check">
                                      <label class="form-check-label">
                                        <input type="radio" value="<?php echo $incorrect_answers_arr[$j]; ?>" class="form-check-input" name="optradio"><?php echo $incorrect_answers_arr[$j];?>
                                        <input type="hidden" name="question_id" value="<?php echo $row['id'];?>">
                                      </label>
                                    </div>
                                <?php } ?>   
                            </form> 
                            <button  type="button" class="btn btn-primary submit" style="margin-top: 28px;"><?php echo ($row['id'] !=10 ? 'Next':'Get Score');?></button>
                          </div>
                        </div>                          
                    </div>
                </div>
            </div>
          </div>                  
         <?php $i++;} ?>   
        <!-- Vendor js -->
        <?php require('footer.php');?>
       
       <script>
        
            
            // var mcq_question_count = '<?php echo count($mcq_questions);?>'; 


           function enter_score(form_no){
                $.ajax({
                  url:'<?php echo base_url();?>home/submit_ans',
                  type:'POST',
                  dataType:'json',
                  data: $('#submit_ans_form_'+form_no).serialize(),
                  
                  success:function(response)
                  {
                    
                  }
                });
                
            }
            


            $(".submit").click(function(){
                
                var parent_id = $(this).parent().parent().parent().parent().parent().parent().attr('id');
                enter_score(parent_id);
                <?php $i=1;
                    foreach($mcq_questions as $row){
                ?>
                var i= '<?php echo $row["id"]?>';
                    if(parent_id == i && parent_id != 10){

                        open_id = parseInt(parent_id, 10) + parseInt(1, 10);
                        $('#'+open_id).show();
                    }
                    else{
                        if(parent_id != '10'){
                            // Get User Results after this 
                            $('#'+parent_id).hide();
                        }
                        else{
                            
                            //console.log(email_id);
                            window.location.href="<?php echo base_url();?>home/get_your_score";
                        }
                    }
                    
                <?php $i++;} ;?>

                
            });

       </script> 

    </body>

<!-- Mirrored from coderthemes.com/minton/layouts/vertical/blue/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 May 2020 06:59:45 GMT -->
</html>