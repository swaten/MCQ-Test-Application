<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from coderthemes.com/minton/layouts/vertical/blue/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 May 2020 06:59:44 GMT -->
<head>
    
        <title>Home</title>
<?php require('head.php');?>
    </head>

    <body>

      <div class="account-pages mt-5 ">
            <div class="container">
                <div class="justify-content-right">        
                    <h3>Users List</h3>
                       <table class="table" id="users_table">
                          <thead class="thead-dark">
                            <tr>
                              <th scope="col">#</th>
                              <th scope="col">Name</th>
                              <th scope="col">Email ID</th>
                              <th scope="col">Score </th>
                            </tr>
                          </thead>
                          <tbody>
                           
                            
                          </tbody>
                        </table>
                </div>
             </div>           
      </div>  


        <!-- end page -->

        <!-- Vendor js -->
        <?php require('footer.php');?>
       
       <script type="text/javascript">
        $(document).ready(function() {
            $('#users_table').DataTable({
                "ajax": {
                    url : "<?php echo base_url("home/get_admin_users") ?>",
                    type : 'POST'
                },
            });
        });
</script> 

    </body>

<!-- Mirrored from coderthemes.com/minton/layouts/vertical/blue/pages-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 03 May 2020 06:59:45 GMT -->
</html>