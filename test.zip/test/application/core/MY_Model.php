<?php
class MY_Model extends CI_Model
{
	public $join_configs = array();
	
    public function get_where_single ($conditions = false, $other_configs = array(), $where_in_conditions = false) {
		$other_configs['single_row'] = true;
		return $this->get_where($conditions, $other_configs, $where_in_conditions);
	}
	
    public function get_where ($conditions = false, $other_configs = array(), $where_in_conditions = false) {
		if ($conditions) $this->db->where($conditions);
		
		if (is_array($other_configs)) {
			if (isset($other_configs['limit'])) $this->db->limit($other_configs['limit']);
			if (isset($other_configs['offset'])) $this->db->offset($other_configs['offset']);
			if (isset($other_configs['order_by'])) $this->db->order_by($other_configs['order_by'], $other_configs['order_dir']);
			if (isset($other_configs['group_by'])) $this->db->group_by($other_configs['group_by']);
		}
		
		if ($where_in_conditions) foreach ($where_in_conditions as $key=>&$values) $this->db->where_in($key, $values);
		if (!is_array($other_configs) || !isset($other_configs['single_row'])) $other_configs['single_row'] = false;
		
		return $this->get($other_configs['single_row']);
	}
	
	public function get ($single_row = false) {
		$this->db->from($this->table);
		
		//performing all the joins
		foreach ($this->join_configs as &$join_config) {
			if (!isset($join_config['type'])) $join_config['type'] = 'inner';
			$this->db->join($join_config['table'], $join_config['on'], $join_config['type']);
		}
		
		$query = $this->db->get();
		if ($single_row) {
			if ($query->num_rows()) return $query->row_array();
			else return false;
		} else {
			if ($query->num_rows()) return $query->result_array();
			else return array();
		}
	}
	
	public function insert ($data) {
		if (empty($this->join_configs)) {
			$this->db->insert($this->table, $data);
			return $this->db->insert_id();
		} else return false;
	}
	
	public function insert_batch ($data) {
		if (empty($this->join_configs)) {
			$this->db->insert_batch($this->table, $data);
			return true;
		} else return false;
	}
	
	public function update ($conditions = false, $data = array(), $where_in_conditions = false) {
		//performing all the joins
		foreach ($this->join_configs as &$join_config) {
			if (!isset($join_config['type'])) $join_config['type'] = 'inner';
			$this->db->join($join_config['table'], $join_config['on'], $join_config['type']);
		}
		
		//setting the data
		$this->db->set($data);
		
	    if ($conditions) $this->db->where($conditions);
		if ($where_in_conditions) foreach ($where_in_conditions as $key=>&$values) $this->db->where_in($key, $values);
		
	    return $this->db->update($this->table);
	}
	
	public function delete ($conditions = false, $where_in_conditions = false) {
		if (empty($this->join_configs)) {
			if (is_array($conditions)) $this->db->where($conditions);
			if (is_array($where_in_conditions)) foreach ($where_in_conditions as $key=>&$values) $this->db->where_in($key, $values);
			
			return $this->db->delete($this->table);
		} else return false;
	}
}
?>