<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
|  Google API Configuration
| -------------------------------------------------------------------
|  client_id         string   Your Google API Client ID.
|  client_secret     string   Your Google API Client secret.
|  redirect_uri      string   URL to redirect back to after login.
|  application_name  string   Your Google application name.
|  api_key           string   Developer key.
|  scopes            string   Specify scopes
*/
$config['google']['client_id']        = '266034927985-gne8odvn29vukh7h0ec9do02gv6r99ko.apps.googleusercontent.com';
$config['google']['client_secret']    = 'gv8cUzHefOPRNhhfoejbQKsU';
$config['google']['redirect_uri']     = 'http://localhost/lyricist/user_authentication';
$config['google']['application_name'] = 'Login to semicolonworld.com';
$config['google']['api_key']          = 'AIzaSyAE6DUO-r48xscMPS6hjpghI2GE4dENwlQ';
$config['google']['scopes']           = array();