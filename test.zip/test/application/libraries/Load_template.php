<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Load_template {

        public function index()
        {
                $ci = get_instance();

                $ci->load->module('template');
        }
}

?>